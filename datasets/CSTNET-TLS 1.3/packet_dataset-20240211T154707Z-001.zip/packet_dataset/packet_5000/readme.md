## Packet_level in CSTNET-TLS 1.3

1. dataset has 120 classes
2. each class has around 5000 samples
3. data files start with **x_** as file name, label files start with **y_**
5. different files are distinguished using **train**, **test** and **valid**

