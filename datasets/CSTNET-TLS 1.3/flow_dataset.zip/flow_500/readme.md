## Flow_level in CSTNET-TLS 1.3

1. dataset has 120 classes
2. each class has around 500 samples
3. data files start with **x_** as file name, label files start with **y_**
4. there are five data types immediately following the file name **x_**, namely *direction*, *length*, *message type*, *time* and *datagram*
5. different files are distinguished using **train**, **test** and **valid**

